[Introduction]
    These are a series of indicators to show Commitments of Traders(COT) data.

    Commitments of Traders(COT) data from Commodity Futures Trading Commission (CFTC) can substitute the "Volume" indicator, as it provide the position and open interest information! It's very cool, though CFTC publishs the report once each week, and the data has a delay of three days.

[How to use]
    Plese refer to the document "COT_User_Guide.pdf", it can be read by Acrobat Reader.

[F.A.Q.]
    Please see the link:
	http://www.veryforex.com/cot/faq.htm

veryforex.com


